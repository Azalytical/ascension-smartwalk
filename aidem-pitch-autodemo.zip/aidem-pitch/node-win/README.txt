Node.js v22.23.4 для Windows x64 с nodejs.org (node-v22.23.4-win-x64.zip, SHA-256 cbc74b5e0982c9dbb41525fd8fb5dcd32fbee237863f7829072f4639a1ce5f20). Нужен только START-Windows.cmd.
